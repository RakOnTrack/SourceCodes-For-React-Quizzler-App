import React, { useState} from "react";
import Link from "next/link";
import { Navbar, Nav, Form, Button, NavDropdown } from "react-bootstrap";
import { useRouter } from "next/router";
import { useAtom } from "jotai";
import { searchHistoryAtom } from "@/store";
import { addToHistory } from "@/lib/userData";
import { readToken, removeToken } from "@/lib/authenticate";

export default function MainNav() {
  const router = useRouter();
  const [isExpanded, setIsExpanded] = useState(false);
  const [searchHistory, setSearchHistory] = useAtom(searchHistoryAtom);

  let token = readToken();



  function logout() {
    setIsExpanded(false);
    removeToken();
    router.push("/login");
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    const searchField = e.target.search.value;
    setIsExpanded(false);
    let queryString = `"title=true&q=${searchField}`;
    setSearchHistory(await addToHistory(`title=true&q=${queryString}`));
    router.push(`/artwork?title=true&q=${searchField}`);
  };
  const handleNavbarToggle = () => {
    setIsExpanded(!isExpanded);
  };
  const handleNavLinkClick = () => {
    setIsExpanded(false);
  };

  return (
    <>
      <Navbar
        className="fixed-top navbar-dark bg-dark"
        expand="lg"
        expanded={isExpanded}
        style={{ padding: "15px 275px " }}
      >
        <Navbar.Brand className="ms-4">Eric Rak</Navbar.Brand>
        <Navbar.Toggle
          aria-controls="basic-navbar-nav"
          onClick={handleNavbarToggle}
        />
        <Navbar.Collapse
          id="basic-navbar-nav"
          className={isExpanded ? "collapse" : ""}
        >
          <Nav className="me-auto">
            <Link href="/" passHref legacyBehavior>
              <Nav.Link
                onClick={handleNavLinkClick}
                active={router.pathname === "/"}
              >
                Home
              </Nav.Link>
            </Link>

            {token && (
              <Link
                href="/search"
                passHref
                legacyBehavior
                active={router.pathname === "/search"}
              >
                <Nav.Link onClick={handleNavLinkClick}>
                  Advanced Search
                </Nav.Link>
              </Link>
            )}
          </Nav>
          {token && (
            <Form className="d-flex" onSubmit={handleSubmit}>
              <Form.Control
                type="search"
                placeholder="Search"
                className="me-2"
                aria-label="Search"
                name="search"
              />
              <Button variant="success" type="submit">
                Search
              </Button>
            </Form>
          )}
          {token ? (
            <Nav className="me-auto">
              <NavDropdown
                title={token && token.userName}
                id="basic-nav-dropdown"
              >
                <Link href="/favourites" passHref legacyBehavior>
                  <NavDropdown.Item
                    onClick={handleNavLinkClick}
                    active={router.pathname === "/favourites"}
                  >
                    Favourites
                  </NavDropdown.Item>
                </Link>
                <Link href="/history" passHref legacyBehavior>
                  <NavDropdown.Item
                    onClick={handleNavLinkClick}
                    active={router.pathname === "/history"}
                  >
                    Search History
                  </NavDropdown.Item>
                </Link>
                <NavDropdown.Item
                  // active={router.pathname === "/history"}
                  onClick={logout}
                >
                  Logout
                </NavDropdown.Item>
              </NavDropdown>
            </Nav>
          ) : (
            <Nav className="me-auto">
              <Link href="/register" passHref legacyBehavior>
                <Nav.Link
                  onClick={handleNavLinkClick}
                  active={router.pathname === "/register"}
                >
                  Register
                </Nav.Link>
              </Link>
              <Link href="/login" passHref legacyBehavior>
                <Nav.Link
                  onClick={handleNavLinkClick}
                  active={router.pathname === "/login"}
                >
                  Login
                </Nav.Link>
              </Link>
            </Nav>
          )}
        </Navbar.Collapse>
      </Navbar>
      <br />
      <br />
      <br />
    </>
  );
}
