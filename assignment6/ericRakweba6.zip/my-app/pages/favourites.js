import React from "react";
import ArtworkCard from "@/components/ArtworkCard";
import { Row, Col, Card } from "react-bootstrap";
import { useAtom } from "jotai";
import { favouritesAtom } from "@/store";

export default function Favourites() {
  const [favouritesList, setFavouritesList] = useAtom(favouritesAtom);
  if(!favouritesList) return null;
  return (
    <>
      <div>
        {favouritesList.length > 0 ? (
          <div>
            {favouritesList.map((currentObjectID) => (
              <Row className="gy-4">
                <p>{currentObjectID}</p>
                <Col lg={3} key={currentObjectID}>
                  <ArtworkCard objectID={currentObjectID} />
                </Col>
              </Row>
            ))}
          </div>
        ) : (
          <Card>
            <Card.Body>
              <h4>Nothing Here</h4>
              Try adding some new artwork to the list.
            </Card.Body>
          </Card>
        )}
      </div>
    </>
  );
}
