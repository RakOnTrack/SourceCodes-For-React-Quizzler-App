import React from 'react';
import { useRouter } from 'next/router';
import ArtworkCardDetail from '@/components/ArtworkCardDetail';

const ArtworkDetail = () => {
  const router = useRouter();
  const { objectID } = router.query;

  return (
    <div>
      <ArtworkCardDetail objectID={objectID} />
    </div>
  );
};

export default ArtworkDetail;
